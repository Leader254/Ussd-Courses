﻿using Data.Auth;

AuthenticationOptions authenticationOptions = new AuthenticationOptions();
authenticationOptions.ShowOptions();