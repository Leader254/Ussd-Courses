﻿using Data.Models;
using System;

namespace Data.Auth
{
    public class AuthenticationOptions
    {
        public enum Authentication
        {
            Login,
            Register,
        }

        public Authentication ShowOptions()
        {
            Console.WriteLine("Authentication Options:");
            Console.WriteLine("1. Login");
            Console.WriteLine("2. Register");

            Console.Write("Select an option: ");
            string input = Console.ReadLine();

            if (IsValidOption(input, 2, out int option))
            {
                switch (option)
                {
                    case (int)Authentication.Login:
                        HandleLogin();
                        break;
                    case (int)Authentication.Register:
                        HandleRegister();
                        break;
                    default:
                        Console.WriteLine("Invalid option.");
                        HandleInvalidOption();
                        break;
                }
            }
            else
            {
                Console.WriteLine("Invalid input.");
                HandleInvalidOption();
            }

            return Authentication.Login;
        }

        public bool IsValidOption(string input, int limit, out int option)
        {
            return int.TryParse(input, out option) && option > 0 && option <= limit;
        }

        private void HandleInvalidOption()
        {
            Console.WriteLine("Please choose a valid option.");
            ShowOptions();
        }

        private void HandleLogin()
        {
            // Logic for handling login
            Console.Write("Enter your username: ");
            string username = Console.ReadLine();

            Console.Write("Enter your password: ");
            string password = Console.ReadLine();

            // Additional login logic
        }

        private void HandleRegister()
        {
            Console.Write("Enter your email: ");
            string email = Console.ReadLine();

            Console.Write("Enter your username: ");
            string username = Console.ReadLine();

            Console.Write("Enter your password: ");
            string password = Console.ReadLine();

            // Create a new registered user instance
            RegUserDTO newUser = new RegUserDTO
            {
                Email = email,
                Username = username,
                Password = password
            };

            StoreUserInFile(newUser);
            Console.WriteLine("User registered successfully");
        }

        private void StoreUserInFile(RegUserDTO user)
        {
            try
            {
                string filePath = "users.txt";

                using (StreamWriter writer = File.AppendText(filePath))
                {
                    writer.WriteLine($"{user.Email},{user.Username},{user.Password}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error storing user: {ex.Message}");
            }
        }
    }
}
